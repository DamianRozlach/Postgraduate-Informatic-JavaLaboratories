package pl.edu.agh.asd1;

public class Exercise05Multiplicity {
    public static final int multiplicity(int n, int m) {
        // TODO: implement
        return 0;
    }
}
