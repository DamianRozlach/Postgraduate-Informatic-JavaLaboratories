package pl.edu.agh.asd1;

public final class Exercise01Abs {

	public static final int abs(int x) {
		// TODO: implement
		return 0;
	}
}
