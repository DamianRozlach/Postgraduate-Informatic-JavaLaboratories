package pl.edu.agh.asd1;

public final class Exercise04Fibonacci {
	
	public static final int fibonacci(int n) {
		// TODO: implement
		return 0;
	}
}
