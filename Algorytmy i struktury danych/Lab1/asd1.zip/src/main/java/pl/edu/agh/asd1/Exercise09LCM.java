package pl.edu.agh.asd1;

public final class Exercise09LCM {

	public static final int leastCommonMultiple(int n, int m) {
		// TODO: implement
		return 0;
	}
}
