package pl.edu.agh.asd1.ex08;

import java.util.Queue;

public class Heap {
    public Heap() {
        //TODO: implement
    }

    public boolean offer(int element) {
        //TODO: Implement
        return false;
    }

    public int poll() {
        //TODO: Implement
        return 0;
    }

    public int size() {
        //TODO: Implent
        return 0;
    }
}
