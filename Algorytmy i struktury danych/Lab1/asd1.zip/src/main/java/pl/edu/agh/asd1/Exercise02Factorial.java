package pl.edu.agh.asd1;

public final class Exercise02Factorial {

	public static final int factorial(int x) {
		// TODO: implement
		return 0;
	}
	
}
