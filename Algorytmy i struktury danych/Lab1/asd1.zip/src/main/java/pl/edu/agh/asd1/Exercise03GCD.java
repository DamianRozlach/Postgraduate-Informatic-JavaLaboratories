package pl.edu.agh.asd1;

public final class Exercise03GCD {

	public static final int greatestCommonDivisor(int n, int m) {
		// TODO: implement
		return 0;
	}
}
