package pl.edu.agh.asd1;

public class Exercise07Palindrome {
    public static final boolean isPalindrome(String n) {
        // TODO: implement
        return false;
    }
}
