package pl.edu.agh.asd1;

public class Exercise06Pesel {
    public static final boolean isPesel(long n) {
        // TODO: implement
        return false;
    }
}
