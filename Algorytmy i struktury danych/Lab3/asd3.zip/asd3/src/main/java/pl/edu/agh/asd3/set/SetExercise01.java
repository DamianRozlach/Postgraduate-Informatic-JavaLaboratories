package pl.edu.agh.asd3.set;

import java.util.Set;

public class SetExercise01 {

	public static Set<String> union(Set<String> first, Set<String> second) {
		//TODO
        return null;
	}
	

}