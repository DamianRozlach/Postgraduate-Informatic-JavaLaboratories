package pl.edu.agh.asd3.map;

import java.util.HashMap;
import java.util.Map;

public class PhoneBook {

    Map<String, String> map = new HashMap<>();

    public void addEntry(String name, String phoneNumber) {
        //TODO
    }

    public String findEntry(String name) {
        //TODO
        return null;
    }

    public boolean existsEntry(String name) {
        //TODO
        return false;
    }

    public boolean checkNumberExists(String phoneNumber) {
        //TODO
        return false;
    }
}
