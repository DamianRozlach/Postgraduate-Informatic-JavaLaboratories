package pl.edu.agh.asd3.stream;

import java.io.IOException;
import java.net.URL;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class StreamExercise01 {

    public static void main(String[] args) {
        analyzePoem(getPoemRows());
    }


    public static void analyzePoem(List<String> rows) {
        // how many lines
        //TODO

        // how many non-empty lines
        //TODO

        // print 5 alphabetically first lines
        //TODO

        // print whole rows with lower case
        //TODO

        // print all rows with Zosia
        //TODO

        // Check how many times exists Litwa and Polska
        //TODO
    }

    public static List<String> getPoemRows() {
        String[] rows = new String[]{};
        try (Scanner scanner = new Scanner(
                new URL("https://wolnelektury.pl/media/book/txt/pan-tadeusz.txt").openStream(), "UTF-8")
                .useDelimiter("\\A")) {
            String whole = scanner.next();
            rows = whole.split("\\r\\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return Arrays.asList(rows);
    }
}
