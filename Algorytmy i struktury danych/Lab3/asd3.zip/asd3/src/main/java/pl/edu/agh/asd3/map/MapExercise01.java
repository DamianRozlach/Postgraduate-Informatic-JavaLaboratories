package pl.edu.agh.asd3.map;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class MapExercise01 {

    public static Map<String, Integer> countWords(List<String> words) {
        //TODO
        return null;
    }
}