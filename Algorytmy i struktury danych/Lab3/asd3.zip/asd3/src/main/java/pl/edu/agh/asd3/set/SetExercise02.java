package pl.edu.agh.asd3.set;


public class SetExercise02 {

    public static int countNumberOfUniqueWords(String text) {
        //TODO
        return 0;
    }

    public static boolean checkIfNameExists(String text, String name) {
        //TODO
        return false;
    }

    private static String[] splitTextToWords(String text) {
        return text.split("\\W");
    }

}
